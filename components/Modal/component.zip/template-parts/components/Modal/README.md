# Modal

Dialog overlay.

## Props

| Name | Type | Default |
|------|------|---------|
| open | boolean | false |
| title | string | "" |
| content | string | "" |
| class | string | "" |
| id | string | "null" |

## Usage

```php
<?php
echo wpsyde_component('Modal', [/* props */]);
```
