// Optional progressive enhancement for Modal
// See javascript/enhancers for global autoinit.
