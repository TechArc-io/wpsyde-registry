// Optional progressive enhancement for Separator
// See javascript/enhancers for global autoinit.
