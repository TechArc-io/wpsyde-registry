<?php
// Example usage for Card
echo wpsyde_component('Card', []);
