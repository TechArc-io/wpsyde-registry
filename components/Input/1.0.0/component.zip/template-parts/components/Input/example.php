<?php
// Example usage for Input
echo wpsyde_component('Input', []);
