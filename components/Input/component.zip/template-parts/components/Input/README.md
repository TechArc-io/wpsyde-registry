# Input

Text input field with focus ring.

## Props

| Name | Type | Default |
|------|------|---------|


## Usage

```php
<?php
echo wpsyde_component('Input', [/* props */]);
```
