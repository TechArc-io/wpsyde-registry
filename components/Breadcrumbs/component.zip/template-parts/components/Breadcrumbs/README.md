# Breadcrumbs

Hierarchy navigation.

## Props

| Name | Type | Default |
|------|------|---------|
| items | string | "[]" |
| class | string | "" |

## Usage

```php
<?php
echo wpsyde_component('Breadcrumbs', [/* props */]);
```
