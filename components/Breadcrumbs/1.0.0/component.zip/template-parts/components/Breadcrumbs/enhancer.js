// Optional progressive enhancement for Breadcrumbs
// See javascript/enhancers for global autoinit.
