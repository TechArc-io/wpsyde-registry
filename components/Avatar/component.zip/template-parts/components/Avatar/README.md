# Avatar

User/image avatar.

## Props

| Name | Type | Default |
|------|------|---------|
| src | string | "" |
| alt | string | "" |
| size | string | "md" |
| class | string | "" |

## Usage

```php
<?php
echo wpsyde_component('Avatar', [/* props */]);
```
