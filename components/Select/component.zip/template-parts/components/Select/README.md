# Select

Dropdown select.

## Props

| Name | Type | Default |
|------|------|---------|
| name | string | "" |
| options | string | "[]" |
| value | string | "" |
| placeholder | string | "" |
| class | string | "" |
| attrs | string | "[]" |

## Usage

```php
<?php
echo wpsyde_component('Select', [/* props */]);
```
