// Optional progressive enhancement for Tooltip
// See javascript/enhancers for global autoinit.
