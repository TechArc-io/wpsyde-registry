# Tooltip

Hover/focus information.

## Props

| Name | Type | Default |
|------|------|---------|
| text | string | "" |
| content | string | "" |
| class | string | "" |

## Usage

```php
<?php
echo wpsyde_component('Tooltip', [/* props */]);
```
