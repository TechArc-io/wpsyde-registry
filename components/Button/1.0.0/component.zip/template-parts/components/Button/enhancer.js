// Optional progressive enhancement for Button
// See javascript/enhancers for global autoinit.
