# Button

Actions with variants and sizes.

## Props

| Name | Type | Default |
|------|------|---------|


## Usage

```php
<?php
echo wpsyde_component('Button', [/* props */]);
```
