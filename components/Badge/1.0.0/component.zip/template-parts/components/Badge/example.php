<?php
// Example usage for Badge
echo wpsyde_component('Badge', []);
