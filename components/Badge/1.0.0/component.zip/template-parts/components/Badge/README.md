# Badge

Small status pill for labeling.

## Props

| Name | Type | Default |
|------|------|---------|


## Usage

```php
<?php
echo wpsyde_component('Badge', [/* props */]);
```
