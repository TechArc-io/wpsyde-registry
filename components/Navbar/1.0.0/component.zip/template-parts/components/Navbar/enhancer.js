// Optional progressive enhancement for Navbar
// See javascript/enhancers for global autoinit.
