# Navbar

Header navigation bar.

## Props

| Name | Type | Default |
|------|------|---------|
| theme_location | string | "menu-1" |
| class | string | "" |

## Usage

```php
<?php
echo wpsyde_component('Navbar', [/* props */]);
```
