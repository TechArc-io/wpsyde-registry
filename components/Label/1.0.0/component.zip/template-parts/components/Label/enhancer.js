// Optional progressive enhancement for Label
// See javascript/enhancers for global autoinit.
