# Label

Form label helper.

## Props

| Name | Type | Default |
|------|------|---------|
| for | string | "" |
| text | string | "" |
| class | string | "" |

## Usage

```php
<?php
echo wpsyde_component('Label', [/* props */]);
```
