<?php
// Example usage for Pagination
echo wpsyde_component('Pagination', []);
