# Tabs

Tabbed content navigation.

## Props

| Name | Type | Default |
|------|------|---------|
| tabs | string | "[]" |
| active | string | "0" |
| class | string | "" |

## Usage

```php
<?php
echo wpsyde_component('Tabs', [/* props */]);
```
