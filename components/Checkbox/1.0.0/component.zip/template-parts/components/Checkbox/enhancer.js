// Optional progressive enhancement for Checkbox
// See javascript/enhancers for global autoinit.
