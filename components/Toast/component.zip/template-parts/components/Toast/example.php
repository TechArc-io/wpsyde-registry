<?php
// Example usage for Toast
echo wpsyde_component('Toast', []);
