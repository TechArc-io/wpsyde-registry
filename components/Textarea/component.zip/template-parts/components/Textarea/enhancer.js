// Optional progressive enhancement for Textarea
// See javascript/enhancers for global autoinit.
