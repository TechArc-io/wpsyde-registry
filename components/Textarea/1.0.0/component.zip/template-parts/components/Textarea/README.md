# Textarea

Multiline input.

## Props

| Name | Type | Default |
|------|------|---------|
| name | string | "" |
| placeholder | string | "" |
| value | string | "" |
| rows | string | "4" |
| class | string | "" |
| attrs | string | "[]" |

## Usage

```php
<?php
echo wpsyde_component('Textarea', [/* props */]);
```
