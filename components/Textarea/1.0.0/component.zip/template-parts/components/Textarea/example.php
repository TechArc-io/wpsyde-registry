<?php
// Example usage for Textarea
echo wpsyde_component('Textarea', []);
