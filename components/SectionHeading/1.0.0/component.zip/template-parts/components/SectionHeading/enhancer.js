// Optional progressive enhancement for SectionHeading
// See javascript/enhancers for global autoinit.
