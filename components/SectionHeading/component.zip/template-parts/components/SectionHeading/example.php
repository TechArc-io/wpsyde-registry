<?php
// Example usage for SectionHeading
echo wpsyde_component('SectionHeading', []);
