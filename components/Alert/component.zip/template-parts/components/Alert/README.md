# Alert

Inline feedback messages.

## Props

| Name | Type | Default |
|------|------|---------|


## Usage

```php
<?php
echo wpsyde_component('Alert', [/* props */]);
```
