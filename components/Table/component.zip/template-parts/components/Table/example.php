<?php
// Example usage for Table
echo wpsyde_component('Table', []);
