<?php
// Example usage for Navbar
echo wpsyde_component('Navbar', []);
