// Optional progressive enhancement for Input
// See javascript/enhancers for global autoinit.
