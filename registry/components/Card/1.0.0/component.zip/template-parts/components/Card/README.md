# Card

Surface container for grouping content.

## Props

| Name | Type | Default |
| ---- | ---- | ------- |

## Usage

```php
<?php
echo wpsyde_component('Card', [/* props */]);
```
