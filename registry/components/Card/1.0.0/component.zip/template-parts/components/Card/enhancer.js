// Optional progressive enhancement for Card
// See javascript/enhancers for global autoinit.
