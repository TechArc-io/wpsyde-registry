# Accordion

Collapsible sections.

## Props

| Name  | Type   | Default |
| ----- | ------ | ------- |
| items | string | "[]"    |
| class | string | ""      |

## Usage

```php
<?php
echo wpsyde_component('Accordion', [/* props */]);
```
