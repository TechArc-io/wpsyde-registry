// Optional progressive enhancement for Accordion
// See javascript/enhancers for global autoinit.
