<?php
// Example usage for Accordion
echo wpsyde_component('Accordion', []);
