// Optional progressive enhancement for Select
// See javascript/enhancers for global autoinit.
