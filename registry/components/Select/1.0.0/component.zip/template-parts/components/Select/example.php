<?php
// Example usage for Select
echo wpsyde_component('Select', []);
