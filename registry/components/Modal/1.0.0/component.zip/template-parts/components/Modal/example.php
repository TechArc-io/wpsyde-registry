<?php
// Example usage for Modal
echo wpsyde_component('Modal', []);
