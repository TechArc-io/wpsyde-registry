<?php
// Example usage for Label
echo wpsyde_component('Label', []);
