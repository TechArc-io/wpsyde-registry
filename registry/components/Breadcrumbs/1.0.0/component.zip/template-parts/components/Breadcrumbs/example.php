<?php
// Example usage for Breadcrumbs
echo wpsyde_component('Breadcrumbs', []);
