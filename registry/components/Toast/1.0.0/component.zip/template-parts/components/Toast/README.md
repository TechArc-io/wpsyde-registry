# Toast

Transient notifications.

## Props

| Name    | Type   | Default |
| ------- | ------ | ------- |
| variant | string | "info"  |
| content | string | ""      |
| class   | string | ""      |

## Usage

```php
<?php
echo wpsyde_component('Toast', [/* props */]);
```
