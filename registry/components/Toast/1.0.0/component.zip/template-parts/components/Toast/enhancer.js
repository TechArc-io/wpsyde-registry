// Optional progressive enhancement for Toast
// See javascript/enhancers for global autoinit.
