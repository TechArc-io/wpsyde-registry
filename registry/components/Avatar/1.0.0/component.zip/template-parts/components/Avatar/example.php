<?php
// Example usage for Avatar
echo wpsyde_component('Avatar', []);
