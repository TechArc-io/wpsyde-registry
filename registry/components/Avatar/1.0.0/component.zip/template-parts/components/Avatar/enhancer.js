// Optional progressive enhancement for Avatar
// See javascript/enhancers for global autoinit.
