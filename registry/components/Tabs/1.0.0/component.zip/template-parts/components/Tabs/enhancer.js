// Optional progressive enhancement for Tabs
// See javascript/enhancers for global autoinit.
