<?php
// Example usage for Tabs
echo wpsyde_component('Tabs', []);
