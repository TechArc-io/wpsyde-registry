// Optional progressive enhancement for Alert
// See javascript/enhancers for global autoinit.
