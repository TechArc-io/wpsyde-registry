<?php
// Example usage for Alert
echo wpsyde_component('Alert', []);
