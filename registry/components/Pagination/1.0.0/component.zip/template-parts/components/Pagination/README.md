# Pagination

Page navigation controls.

## Props

| Name  | Type   | Default |
| ----- | ------ | ------- |
| query | string | "null"  |
| class | string | ""      |

## Usage

```php
<?php
echo wpsyde_component('Pagination', [/* props */]);
```
