// Optional progressive enhancement for Pagination
// See javascript/enhancers for global autoinit.
