<?php
// Example usage for Separator
echo wpsyde_component('Separator', []);
