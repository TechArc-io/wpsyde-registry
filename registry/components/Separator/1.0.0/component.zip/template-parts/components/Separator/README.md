# Separator

Horizontal rule/divider.

## Props

| Name  | Type   | Default |
| ----- | ------ | ------- |
| class | string | ""      |

## Usage

```php
<?php
echo wpsyde_component('Separator', [/* props */]);
```
