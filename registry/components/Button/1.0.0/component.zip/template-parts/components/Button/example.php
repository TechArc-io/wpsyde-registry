<?php
// Example usage for Button
echo wpsyde_component('Button', []);
