// Optional progressive enhancement for Table
// See javascript/enhancers for global autoinit.
