# Table

Data table primitives.

## Props

| Name    | Type   | Default |
| ------- | ------ | ------- |
| headers | string | "[]"    |
| rows    | string | "[]"    |
| class   | string | ""      |

## Usage

```php
<?php
echo wpsyde_component('Table', [/* props */]);
```
