# SectionHeading

Title + optional description block.

## Props

| Name | Type | Default |
| ---- | ---- | ------- |

## Usage

```php
<?php
echo wpsyde_component('SectionHeading', [/* props */]);
```
