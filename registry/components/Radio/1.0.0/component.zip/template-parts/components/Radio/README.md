# Radio

Radio group input.

## Props

| Name    | Type    | Default |
| ------- | ------- | ------- |
| name    | string  | ""      |
| value   | string  | ""      |
| checked | boolean | false   |
| label   | string  | ""      |
| class   | string  | ""      |
| attrs   | string  | "[]"    |

## Usage

```php
<?php
echo wpsyde_component('Radio', [/* props */]);
```
