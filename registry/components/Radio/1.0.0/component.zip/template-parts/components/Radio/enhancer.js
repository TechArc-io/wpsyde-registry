// Optional progressive enhancement for Radio
// See javascript/enhancers for global autoinit.
