<?php
// Example usage for Radio
echo wpsyde_component('Radio', []);
