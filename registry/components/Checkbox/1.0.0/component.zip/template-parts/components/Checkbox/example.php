<?php
// Example usage for Checkbox
echo wpsyde_component('Checkbox', []);
