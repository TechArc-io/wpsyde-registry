<?php
// Example usage for Tooltip
echo wpsyde_component('Tooltip', []);
