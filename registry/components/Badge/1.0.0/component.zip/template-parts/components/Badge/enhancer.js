// Optional progressive enhancement for Badge
// See javascript/enhancers for global autoinit.
